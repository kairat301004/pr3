package lab3.differentiation;

/**
 * Численное дифференцирование таблично заданной функции с постоянным шагом h.
 * Все формулы используют только значения y_i из таблицы.
 */
public final class FiniteDifferences {

    private FiniteDifferences() {
    }

    /** Левая разность: y'_i ≈ (y_i - y_(i-1)) / h, погрешность O(h). */
    public static double left(double[] y, double h, int i) {
        return (y[i] - y[i - 1]) / h;
    }

    /** Правая разность: y'_i ≈ (y_(i+1) - y_i) / h, погрешность O(h). */
    public static double right(double[] y, double h, int i) {
        return (y[i + 1] - y[i]) / h;
    }

    /** Центральная разность: y'_i ≈ (y_(i+1) - y_(i-1)) / (2h), погрешность O(h^2). */
    public static double central(double[] y, double h, int i) {
        return (y[i + 1] - y[i - 1]) / (2.0 * h);
    }

    /** Односторонняя правая формула второго порядка (для первого узла): (-3y_i + 4y_(i+1) - y_(i+2)) / (2h). */
    public static double rightSecondOrder(double[] y, double h, int i) {
        return (-3.0 * y[i] + 4.0 * y[i + 1] - y[i + 2]) / (2.0 * h);
    }

    /** Односторонняя левая формула второго порядка (для последнего узла): (3y_i - 4y_(i-1) + y_(i-2)) / (2h). */
    public static double leftSecondOrder(double[] y, double h, int i) {
        return (3.0 * y[i] - 4.0 * y[i - 1] + y[i - 2]) / (2.0 * h);
    }

    /** Вторая производная во внутреннем узле: (y_(i+1) - 2y_i + y_(i-1)) / h^2, погрешность O(h^2). */
    public static double second(double[] y, double h, int i) {
        return (y[i + 1] - 2.0 * y[i] + y[i - 1]) / (h * h);
    }
}
