package lab3;

import lab3.approximation.LeastSquares;
import lab3.differentiation.FiniteDifferences;
import lab3.functions.Variant1;
import lab3.interpolation.LagrangePolynomial;
import lab3.interpolation.NewtonPolynomial;
import lab3.output.Csv;
import lab3.output.LineChart;
import lab3.output.LineChart.Style;
import lab3.polynomial.Polynomial;

import java.awt.Color;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Практическая работа №3 «Интерполяция, численное дифференцирование, МНК».
 * Номер зачётной книжки N = 14, номер функции (14 mod 7) + 1 = 1:
 * f(x) = x^2 - x - 5, диапазон [0; 10].
 *
 * <p>Результаты: консоль, CSV и PNG-графики в каталоге {@code output/}.</p>
 */
public final class Main {

    // Параметры случайной составляющей (часть 2).
    private static final double NOISE_SIGMA = 2.0;
    private static final long NOISE_SEED = 14L;
    private static final int MAX_LSM_DEGREE = 4;
    private static final int STAT_TRIALS = 10_000;

    private static final Color C_F = new Color(31, 119, 180);
    private static final Color C_ORANGE = new Color(255, 127, 14);
    private static final Color C_GREEN = new Color(44, 160, 44);
    private static final Color C_RED = new Color(214, 39, 40);
    private static final Color C_PURPLE = new Color(148, 103, 189);
    private static final Color C_GRAY = new Color(110, 110, 110);

    private static PrintStream out;

    private Main() {
    }

    public static void main(String[] args) throws IOException {
        out = new PrintStream(new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8);
        Path dir = Path.of(args.length > 0 ? args[0] : "output");

        double[] x = Variant1.nodes();
        double[] y = new double[x.length];
        for (int i = 0; i < x.length; i++) {
            y[i] = Variant1.f(x[i]);
        }
        double h = Variant1.step();

        header("ИСХОДНЫЕ ДАННЫЕ");
        out.printf("Номер зачётной книжки N = %d, номер функции (N mod 7) + 1 = %d%n",
                Variant1.RECORD_BOOK, Variant1.FUNCTION_NUMBER);
        out.printf(Locale.US, "f(x) = x^2 - x - 5, диапазон [%.0f; %.0f], разбиение на %d частей, h = %.15f%n",
                Variant1.A, Variant1.B, Variant1.PARTS, h);
        out.println("Отброшены крайние точки x = 0 и x = 10. Таблица:");
        out.printf("%3s %20s %20s%n", "i", "x_i", "y_i = f(x_i)");
        Csv table = new Csv(dir.resolve("part1_table.csv"), "i", "x", "y");
        for (int i = 0; i < x.length; i++) {
            out.printf(Locale.US, "%3d %20.15f %20.15f%n", i + 1, x[i], y[i]);
            table.row(i + 1, x[i], y[i]);
        }
        table.save();

        LagrangePolynomial lagrange = new LagrangePolynomial(x, y);
        NewtonPolynomial newton = new NewtonPolynomial(x, y);
        interpolation(dir, x, y, lagrange, newton);
        intervals(dir, x, y, h, lagrange, newton);
        derivatives(dir, x, y, h);
        leastSquares(dir, x, y);

        out.println();
        out.println("Файлы результатов сохранены в каталог: " + dir.toAbsolutePath());
    }

    // =====================================================================
    // Часть 1. Интерполяционные многочлены Лагранжа и Ньютона
    // =====================================================================
    private static void interpolation(Path dir, double[] x, double[] y,
                                      LagrangePolynomial lagrange, NewtonPolynomial newton) throws IOException {
        header("ЧАСТЬ 1. ИНТЕРПОЛЯЦИЯ");
        int n = x.length;

        double[][] dd = newton.dividedDifferences();
        out.println("Таблица разделённых разностей f[x_i, ..., x_(i+k)]:");
        Csv ddCsv = new Csv(dir.resolve("part1_divided_differences.csv"), "i", "k0", "k1", "k2", "k3", "k4", "k5");
        for (int i = 0; i < n; i++) {
            out.printf("%3d", i + 1);
            Object[] row = new Object[n + 1];
            row[0] = i + 1;
            for (int k = 0; k < n; k++) {
                if (i < dd[k].length) {
                    out.printf(Locale.US, " %13.5e", dd[k][i]);
                    row[k + 1] = dd[k][i];
                } else {
                    row[k + 1] = Double.NaN;
                }
            }
            out.println();
            ddCsv.row(row);
        }
        ddCsv.save();

        double[] c = newton.coefficients();
        out.println("Коэффициенты многочлена Ньютона (f[x1], f[x1,x2], ...):");
        for (int k = 0; k < c.length; k++) {
            out.printf(Locale.US, "  c%d = %+.15e%n", k, c[k]);
        }
        Polynomial mono = newton.toMonomial();
        out.println("Многочлен в стандартном виде (a0 + a1 x + ... + a5 x^5):");
        double[] a = mono.coefficients();
        Csv monoCsv = new Csv(dir.resolve("part1_monomial.csv"), "k", "a_k");
        for (int k = 0; k < a.length; k++) {
            out.printf(Locale.US, "  a%d = %+.15e%n", k, a[k]);
            monoCsv.row(k, a[k]);
        }
        monoCsv.save();

        double nodeErrL = 0, nodeErrN = 0;
        for (int i = 0; i < n; i++) {
            nodeErrL = Math.max(nodeErrL, Math.abs(lagrange.value(x[i]) - y[i]));
            nodeErrN = Math.max(nodeErrN, Math.abs(newton.value(x[i]) - y[i]));
        }
        out.printf(Locale.US, "Проверка в узлах: max|L(x_i) - y_i| = %.3e, max|N(x_i) - y_i| = %.3e%n",
                nodeErrL, nodeErrN);

        // Плотная сетка на всём диапазоне [0; 10].
        int m = 1000;
        double[] gx = new double[m + 1];
        double[] gf = new double[m + 1];
        double[] gl = new double[m + 1];
        double[] gn = new double[m + 1];
        double[] el = new double[m + 1];
        double[] en = new double[m + 1];
        double[] eln = new double[m + 1];
        double maxL = 0, maxN = 0, maxLN = 0, maxLin = 0, maxNin = 0;
        for (int i = 0; i <= m; i++) {
            gx[i] = Variant1.A + (Variant1.B - Variant1.A) * i / m;
            gf[i] = Variant1.f(gx[i]);
            gl[i] = lagrange.value(gx[i]);
            gn[i] = newton.value(gx[i]);
            el[i] = Math.abs(gl[i] - gf[i]);
            en[i] = Math.abs(gn[i] - gf[i]);
            eln[i] = Math.abs(gl[i] - gn[i]);
            maxL = Math.max(maxL, el[i]);
            maxN = Math.max(maxN, en[i]);
            maxLN = Math.max(maxLN, eln[i]);
            if (gx[i] >= x[0] && gx[i] <= x[n - 1]) {
                maxLin = Math.max(maxLin, el[i]);
                maxNin = Math.max(maxNin, en[i]);
            }
        }
        out.printf(Locale.US, "На [x1; x6] (1001 точка сетки): max|L - f| = %.3e, max|N - f| = %.3e%n", maxLin, maxNin);
        out.printf(Locale.US, "На [0; 10]: max|L - f| = %.3e, max|N - f| = %.3e, max|L - N| = %.3e%n", maxL, maxN, maxLN);

        new LineChart("Интерполяционные многочлены и точки таблицы", "x", "y")
                .xRange(0, 10, 1.0).legendBottom(true)
                .addVLine(x[0], "x₁", C_GRAY)
                .addVLine(x[n - 1], "x₆", C_GRAY)
                .addSeries("f(x) = x² − x − 5", gx, gf, C_F, Style.LINE, false)
                .addSeries("многочлен Лагранжа L₅(x)", gx, gl, C_ORANGE, Style.DASHED, false)
                .addSeries("многочлен Ньютона N₅(x)", gx, gn, C_RED, Style.DOTTED, false)
                .addSeries("узлы таблицы", x, y, Color.BLACK, Style.POINTS, true)
                .save(dir.resolve("part1_interpolation.png"), 1400, 900);

        new LineChart("Погрешность интерполяции", "x", "Модуль разности")
                .logY(true)
                .xRange(0, 10, 1.0)
                .addSeries("|L₅(x) − f(x)|", gx, el, C_ORANGE, Style.LINE, false)
                .addSeries("|N₅(x) − f(x)|", gx, en, C_RED, Style.LINE, false)
                .save(dir.resolve("part1_interpolation_error.png"), 1400, 800);
    }

    // =====================================================================
    // Участки с минимальной и максимальной разностью соседних значений
    // =====================================================================
    private static void intervals(Path dir, double[] x, double[] y, double h,
                                  LagrangePolynomial lagrange, NewtonPolynomial newton) throws IOException {
        header("УЧАСТКИ С МИНИМАЛЬНОЙ И МАКСИМАЛЬНОЙ РАЗНОСТЬЮ |y_(i+1) - y_i|");
        int iMin = 0, iMax = 0;
        Csv diffCsv = new Csv(dir.resolve("part1_differences.csv"), "i", "x_i", "x_i1", "abs_dy");
        for (int i = 0; i + 1 < x.length; i++) {
            double d = Math.abs(y[i + 1] - y[i]);
            out.printf(Locale.US, "[x%d; x%d] = [%.6f; %.6f]: |dy| = %.10f%n", i + 1, i + 2, x[i], x[i + 1], d);
            diffCsv.row(i + 1, x[i], x[i + 1], d);
            if (d < Math.abs(y[iMin + 1] - y[iMin])) {
                iMin = i;
            }
            if (d > Math.abs(y[iMax + 1] - y[iMax])) {
                iMax = i;
            }
        }
        diffCsv.save();
        out.printf("Минимальная разность: [x%d; x%d], максимальная: [x%d; x%d]%n", iMin + 1, iMin + 2, iMax + 1, iMax + 2);

        Csv csv = new Csv(dir.resolve("part1_intervals.csv"),
                "interval", "j", "x", "f", "L", "N", "abs_L_f", "abs_N_f");
        for (int[] spec : new int[][]{{iMin, 0}, {iMax, 1}}) {
            int i = spec[0];
            String name = spec[1] == 0 ? "min" : "max";
            out.printf(Locale.US, "%nУчасток [x%d; x%d] (%s), шаг h/4 = %.10f:%n", i + 1, i + 2, name, h / 4);
            out.printf("%3s %18s %22s %22s %22s %11s %11s%n", "j", "x", "f(x)", "L(x)", "N(x)", "|L-f|", "|N-f|");
            for (int j = 0; j <= 4; j++) {
                double t = x[i] + j * (x[i + 1] - x[i]) / 4.0;
                double ft = Variant1.f(t);
                double lt = lagrange.value(t);
                double nt = newton.value(t);
                out.printf(Locale.US, "%3d %18.12f %22.15f %22.15f %22.15f %11.3e %11.3e%n",
                        j, t, ft, lt, nt, Math.abs(lt - ft), Math.abs(nt - ft));
                csv.row(name, j, t, ft, lt, nt, Math.abs(lt - ft), Math.abs(nt - ft));
            }
        }
        csv.save();
    }

    // =====================================================================
    // Численное дифференцирование
    // =====================================================================
    private static void derivatives(Path dir, double[] x, double[] y, double h) throws IOException {
        header("ПЕРВАЯ ПРОИЗВОДНАЯ В УЗЛАХ ТАБЛИЦЫ");
        int n = x.length;
        out.printf("%3s %10s %14s %14s %14s %14s %14s %11s %11s %11s %11s%n", "i", "x_i", "f'(x_i)",
                "левая", "правая", "центральная", "2-й пор.(кр.)", "ош.лев", "ош.прав", "ош.центр", "ош.2пор");
        Csv csv = new Csv(dir.resolve("part1_first_derivative.csv"), "i", "x", "exact",
                "left", "right", "central", "edge2", "err_left", "err_right", "err_central", "err_edge2");
        double[] lx = new double[n - 1], ly = new double[n - 1];
        double[] rx = new double[n - 1], ry = new double[n - 1];
        double[] cx = new double[n - 2], cy = new double[n - 2];
        double[] ex = {x[0], x[n - 1]};
        double[] ey = new double[2];
        for (int i = 0; i < n; i++) {
            double exact = Variant1.df(x[i]);
            double left = i > 0 ? FiniteDifferences.left(y, h, i) : Double.NaN;
            double right = i < n - 1 ? FiniteDifferences.right(y, h, i) : Double.NaN;
            double central = i > 0 && i < n - 1 ? FiniteDifferences.central(y, h, i) : Double.NaN;
            double edge = i == 0 ? FiniteDifferences.rightSecondOrder(y, h, i)
                    : i == n - 1 ? FiniteDifferences.leftSecondOrder(y, h, i) : Double.NaN;
            out.printf(Locale.US, "%3d %10.6f %14.10f %14s %14s %14s %14s %11s %11s %11s %11s%n", i + 1, x[i], exact,
                    f10(left), f10(right), f10(central), f10(edge),
                    e3(left - exact), e3(right - exact), e3(central - exact), e3(edge - exact));
            csv.row(i + 1, x[i], exact, left, right, central, edge,
                    left - exact, right - exact, central - exact, edge - exact);
            if (i > 0) {
                lx[i - 1] = x[i];
                ly[i - 1] = left;
            }
            if (i < n - 1) {
                rx[i] = x[i];
                ry[i] = right;
            }
            if (i > 0 && i < n - 1) {
                cx[i - 1] = x[i];
                cy[i - 1] = central;
            }
            if (i == 0) {
                ey[0] = edge;
            }
            if (i == n - 1) {
                ey[1] = edge;
            }
        }
        csv.save();
        out.printf(Locale.US, "Теоретическая погрешность левой и правой схем: -/+ h*f''/2 = -/+ %.10f%n", h);

        int m = 400;
        double[] gx = new double[m + 1];
        double[] gd = new double[m + 1];
        for (int i = 0; i <= m; i++) {
            gx[i] = x[0] - 0.3 + (x[n - 1] - x[0] + 0.6) * i / m;
            gd[i] = Variant1.df(gx[i]);
        }
        new LineChart("Первая производная: точные и приближённые значения", "x", "f′(x)")
                .legendLeft(true)
                .addSeries("f′(x) = 2x − 1", gx, gd, C_F, Style.LINE, false)
                .addSeries("левая разность", lx, ly, C_GREEN, Style.POINTS, true)
                .addSeries("правая разность", rx, ry, C_ORANGE, Style.POINTS, true)
                .addSeries("центральная разность", cx, cy, C_RED, Style.POINTS, true)
                .addSeries("одностор. 2-го порядка", ex, ey, C_PURPLE, Style.POINTS, true)
                .save(dir.resolve("part1_first_derivative.png"), 1400, 900);

        header("ВТОРАЯ ПРОИЗВОДНАЯ ВО ВНУТРЕННИХ УЗЛАХ");
        out.printf("%3s %10s %14s %20s %11s%n", "i", "x_i", "f''(x_i)", "(y+ - 2y + y-)/h^2", "ошибка");
        Csv csv2 = new Csv(dir.resolve("part1_second_derivative.csv"), "i", "x", "exact", "approx", "err");
        for (int i = 1; i < n - 1; i++) {
            double exact = Variant1.d2f(x[i]);
            double approx = FiniteDifferences.second(y, h, i);
            out.printf(Locale.US, "%3d %10.6f %14.10f %20.15f %11.3e%n", i + 1, x[i], exact, approx, approx - exact);
            csv2.row(i + 1, x[i], exact, approx, approx - exact);
        }
        csv2.save();
    }

    // =====================================================================
    // Часть 2. Метод наименьших квадратов
    // =====================================================================
    private static void leastSquares(Path dir, double[] x, double[] y) throws IOException {
        header("ЧАСТЬ 2. МЕТОД НАИМЕНЬШИХ КВАДРАТОВ");
        int n = x.length;
        Random random = new Random(NOISE_SEED);
        double[] noise = new double[n];
        double[] yn = new double[n];
        out.printf(Locale.US, "Случайная составляющая: нормальное распределение N(0; %.1f^2), seed = %d%n",
                NOISE_SIGMA, NOISE_SEED);
        out.printf("%3s %12s %16s %12s %16s%n", "i", "x_i", "y_i", "ξ_i", "ỹ_i = y_i + ξ_i");
        Csv noisy = new Csv(dir.resolve("part2_noisy_table.csv"), "i", "x", "y", "noise", "y_noisy");
        for (int i = 0; i < n; i++) {
            noise[i] = NOISE_SIGMA * random.nextGaussian();
            yn[i] = y[i] + noise[i];
            out.printf(Locale.US, "%3d %12.6f %16.10f %12.6f %16.10f%n", i + 1, x[i], y[i], noise[i], yn[i]);
            noisy.row(i + 1, x[i], y[i], noise[i], yn[i]);
        }
        noisy.save();

        List<LeastSquares.Fit> fits = new ArrayList<>();
        double[] loo = new double[MAX_LSM_DEGREE + 1];
        Csv fitCsv = new Csv(dir.resolve("part2_fits.csv"), "m", "S", "sigma", "F", "F_crit", "loo",
                "max_dev_from_f", "orth", "a0", "a1", "a2", "a3", "a4", "a5");
        out.printf("%n%2s %13s %11s %11s %9s %11s %12s %10s   коэффициенты a0..am%n",
                "m", "S_m", "σ_m", "F(m-1→m)", "F_кр", "LOO", "max|P-f|", "ортог.");
        int bySigma = 0;
        int byLoo = 0;
        for (int m = 0; m <= n - 1; m++) {
            LeastSquares.Fit fit = LeastSquares.fit(x, yn, m);
            fits.add(fit);
            double fStat = Double.NaN;
            double fCrit = Double.NaN;
            if (m >= 1 && m <= MAX_LSM_DEGREE) {
                fStat = LeastSquares.fStatistic(fits.get(m - 1), fit, n);
                fCrit = LeastSquares.fCritical(n - m - 1);
            }
            double cv = Double.NaN;
            if (m <= MAX_LSM_DEGREE) {
                cv = LeastSquares.leaveOneOutError(x, yn, m);
                loo[m] = cv;
                if (fit.sigma() < fits.get(bySigma).sigma()) {
                    bySigma = m;
                }
                if (cv < loo[byLoo]) {
                    byLoo = m;
                }
            }
            double dev = maxDeviationFromF(fit.polynomial(), x[0], x[n - 1]);
            double[] a = fit.polynomial().coefficients();
            StringBuilder sb = new StringBuilder();
            for (double v : a) {
                sb.append(String.format(Locale.US, " %+.6f", v));
            }
            out.printf(Locale.US, "%2d %13.6f %11s %11s %9s %11s %12.6f %10.2e  %s%n", m, fit.sumSquares(),
                    num(fit.sigma(), 6), num(fStat, 3), num(fCrit, 3), num(cv, 4), dev, fit.orthogonality(), sb);
            Object[] row = new Object[14];
            row[0] = m;
            row[1] = fit.sumSquares();
            row[2] = fit.sigma();
            row[3] = fStat;
            row[4] = fCrit;
            row[5] = cv;
            row[6] = dev;
            row[7] = fit.orthogonality();
            for (int k = 0; k < 6; k++) {
                row[8 + k] = k < a.length ? a[k] : Double.NaN;
            }
            fitCsv.row(row);
        }
        fitCsv.save();
        int byF = LeastSquares.degreeByFTest(x, yn, MAX_LSM_DEGREE);
        int best = byF;
        out.printf("Степень по F-критерию Фишера (α = 0,05): m = %d%n", byF);
        out.printf("Степень по минимуму ошибки перекрёстной проверки (LOO): m = %d%n", byLoo);
        out.printf("Степень по формальному минимуму σ_m: m = %d (при n - m - 1 = %d степенях свободы оценка σ ненадёжна)%n",
                bySigma, n - bySigma - 1);
        out.println("Степень m = 5 = n - 1 даёт интерполяцию зашумлённых данных (S = 0, σ не определена).");

        // Устойчивость критериев: статистика по многим реализациям шума.
        Random statRandom = new Random(2026L);
        int[][] counts = new int[3][MAX_LSM_DEGREE + 1];
        for (int t = 0; t < STAT_TRIALS; t++) {
            double[] ys = new double[n];
            for (int i = 0; i < n; i++) {
                ys[i] = y[i] + NOISE_SIGMA * statRandom.nextGaussian();
            }
            int bs = 0;
            int bl = 0;
            double vs = Double.POSITIVE_INFINITY;
            double vl = Double.POSITIVE_INFINITY;
            for (int m = 0; m <= MAX_LSM_DEGREE; m++) {
                double s = LeastSquares.fit(x, ys, m).sigma();
                double l = LeastSquares.leaveOneOutError(x, ys, m);
                if (s < vs) {
                    vs = s;
                    bs = m;
                }
                if (l < vl) {
                    vl = l;
                    bl = m;
                }
            }
            counts[0][LeastSquares.degreeByFTest(x, ys, MAX_LSM_DEGREE)]++;
            counts[1][bl]++;
            counts[2][bs]++;
        }
        out.printf("Частота выбора степени по %d реализациям шума (F-критерий / LOO / min σ):%n", STAT_TRIALS);
        Csv stat = new Csv(dir.resolve("part2_degree_statistics.csv"), "m", "share_F", "share_LOO", "share_sigma");
        for (int m = 0; m <= MAX_LSM_DEGREE; m++) {
            out.printf(Locale.US, "  m = %d: %6.1f %% / %6.1f %% / %6.1f %%%n", m,
                    100.0 * counts[0][m] / STAT_TRIALS, 100.0 * counts[1][m] / STAT_TRIALS,
                    100.0 * counts[2][m] / STAT_TRIALS);
            stat.row(m, (double) counts[0][m] / STAT_TRIALS, (double) counts[1][m] / STAT_TRIALS,
                    (double) counts[2][m] / STAT_TRIALS);
        }
        stat.save();

        // Графики
        int g = 1000;
        double lo = 0.0, hi = 10.0;
        double[] gx = new double[g + 1];
        double[] gf = new double[g + 1];
        for (int i = 0; i <= g; i++) {
            gx[i] = lo + (hi - lo) * i / g;
            gf[i] = Variant1.f(gx[i]);
        }
        LineChart chart = new LineChart("Аппроксимация зашумлённой таблицы методом наименьших квадратов", "x", "y")
                .xRange(lo, hi, 1.0).legendLeft(true)
                .addSeries("f(x) = x² − x − 5", gx, gf, C_GRAY, Style.LINE, false)
                .addSeries("МНК, m = 1", gx, eval(fits.get(1).polynomial(), gx), C_GREEN, Style.DASHED, false)
                .addSeries("МНК, m = " + best + " (выбранная степень)", gx, eval(fits.get(best).polynomial(), gx), C_RED, Style.LINE, false)
                .addSeries("МНК, m = 3", gx, eval(fits.get(3).polynomial(), gx), C_PURPLE, Style.DOTTED, false)
                .addSeries("зашумлённые узлы", x, yn, Color.BLACK, Style.POINTS, true);
        chart.save(dir.resolve("part2_lsm.png"), 1400, 900);

        new LineChart("Интерполяция зашумлённых данных (m = 5) и МНК (m = " + best + ")", "x", "y")
                .xRange(lo, hi, 1.0).legendLeft(true)
                .addSeries("f(x) = x² − x − 5", gx, gf, C_GRAY, Style.LINE, false)
                .addSeries("МНК, m = " + best, gx, eval(fits.get(best).polynomial(), gx), C_RED, Style.LINE, false)
                .addSeries("интерполяция, m = 5", gx, eval(fits.get(5).polynomial(), gx), C_ORANGE, Style.DASHED, false)
                .addSeries("зашумлённые узлы", x, yn, Color.BLACK, Style.POINTS, true)
                .save(dir.resolve("part2_overfitting.png"), 1400, 900);

        double[] ms = new double[MAX_LSM_DEGREE + 1];
        double[] sig = new double[MAX_LSM_DEGREE + 1];
        for (int m = 0; m <= MAX_LSM_DEGREE; m++) {
            ms[m] = m;
            sig[m] = fits.get(m).sigma();
        }
        new LineChart("Качество аппроксимации в зависимости от степени m", "Степень многочлена m", "Величина")
                .logY(true).integerX(true)
                .addHLine(NOISE_SIGMA, "σ шума = 2", C_GRAY)
                .addSeries("σₘ = √(Sₘ/(n − m − 1))", ms, sig, C_RED, Style.LINE, true)
                .addSeries("ошибка перекрёстной проверки", ms, loo, C_F, Style.DASHED, true)
                .save(dir.resolve("part2_sigma.png"), 1400, 800);
    }

    // ---------------------------------------------------------------------
    private static double maxDeviationFromF(Polynomial p, double from, double to) {
        double max = 0;
        int m = 1000;
        for (int i = 0; i <= m; i++) {
            double t = from + (to - from) * i / m;
            max = Math.max(max, Math.abs(p.value(t) - Variant1.f(t)));
        }
        return max;
    }

    private static double[] eval(Polynomial p, double[] xs) {
        double[] r = new double[xs.length];
        for (int i = 0; i < xs.length; i++) {
            r[i] = p.value(xs[i]);
        }
        return r;
    }

    private static String num(double v, int digits) {
        return Double.isNaN(v) ? "—" : String.format(Locale.US, "%." + digits + "f", v);
    }

    private static String f10(double v) {
        return Double.isNaN(v) ? "—" : String.format(Locale.US, "%.10f", v);
    }

    private static String e3(double v) {
        return Double.isNaN(v) ? "—" : String.format(Locale.US, "%+.2e", v);
    }

    private static void header(String title) {
        out.println();
        out.println("=====================================================================");
        out.println(" " + title);
        out.println("=====================================================================");
    }
}
