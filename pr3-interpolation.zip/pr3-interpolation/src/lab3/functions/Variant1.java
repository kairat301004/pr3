package lab3.functions;

/**
 * Функция варианта. Номер функции: (N mod 7) + 1, N = 14 — номер зачётной книжки,
 * (14 mod 7) + 1 = 1, т. е. f(x) = x^2 - x - 5 на отрезке [0; 10].
 */
public final class Variant1 {

    /** Номер зачётной книжки. */
    public static final int RECORD_BOOK = 14;
    /** Номер функции из приложения 1. */
    public static final int FUNCTION_NUMBER = RECORD_BOOK % 7 + 1;

    /** Заданный диапазон. */
    public static final double A = 0.0;
    public static final double B = 10.0;
    /** Число равных частей, на которые разбивается диапазон. */
    public static final int PARTS = 7;

    private Variant1() {
    }

    /** f(x) = x^2 - x - 5 */
    public static double f(double x) {
        return x * x - x - 5.0;
    }

    /** f'(x) = 2x - 1 (точное значение для сравнения). */
    public static double df(double x) {
        return 2.0 * x - 1.0;
    }

    /** f''(x) = 2 (точное значение для сравнения). */
    public static double d2f(double x) {
        return 2.0;
    }

    /**
     * Абсциссы узлов: диапазон [A; B] делится на PARTS равных частей,
     * крайние точки A и B отбрасываются — остаётся PARTS - 1 узлов.
     */
    public static double[] nodes() {
        double h = step();
        double[] x = new double[PARTS - 1];
        for (int i = 1; i < PARTS; i++) {
            x[i - 1] = A + i * h;
        }
        return x;
    }

    /** Шаг таблицы h = (B - A) / PARTS. */
    public static double step() {
        return (B - A) / PARTS;
    }
}
