package lab3.output;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.DoubleUnaryOperator;

/**
 * Построитель графиков в PNG на чистом Java 2D (без сторонних библиотек).
 * Логарифмическая ось Y, несколько серий (линии / пунктир / отдельные точки),
 * легенда, горизонтальные и вертикальные опорные линии.
 * Числа на осях выводятся с десятичной запятой.
 */
public class LineChart {

    /** Стиль серии. */
    public enum Style { LINE, DASHED, DOTTED, POINTS }

    public record Series(String name, double[] x, double[] y, Color color,
                         Style style, boolean markers) {
    }

    private record RefLine(double value, String label, Color color) {
    }

    private record Note(double x, double y, String text, int dx, int dy) {
    }

    private final String title;
    private final String xLabel;
    private final String yLabel;
    private final List<Series> series = new ArrayList<>();
    private final List<RefLine> vLines = new ArrayList<>();
    private final List<RefLine> hLines = new ArrayList<>();
    private final List<Note> notes = new ArrayList<>();
    private boolean logY;
    private boolean legendLeft;
    private boolean legendBottom;
    private boolean zeroLine;
    private boolean integerX;
    private Double xMinFixed, xMaxFixed, yMinFixed, yMaxFixed;
    private Double xStepFixed, yStepFixed;

    private static final Font TITLE_FONT = new Font("DejaVu Sans", Font.BOLD, 30);
    private static final Font LABEL_FONT = new Font("DejaVu Sans", Font.PLAIN, 26);
    private static final Font TICK_FONT = new Font("DejaVu Sans", Font.PLAIN, 22);
    private static final Font EXP_FONT = new Font("DejaVu Sans", Font.PLAIN, 16);

    private static final int LEFT = 150, RIGHT = 50, TOP = 80, BOTTOM = 110;

    public LineChart(String title, String xLabel, String yLabel) {
        this.title = title;
        this.xLabel = xLabel;
        this.yLabel = yLabel;
    }

    public LineChart logY(boolean value) {
        this.logY = value;
        return this;
    }

    /** Разместить легенду в левом верхнем углу (по умолчанию — в правом). */
    public LineChart legendLeft(boolean value) {
        this.legendLeft = value;
        return this;
    }

    /** Разместить легенду в правом нижнем углу. */
    public LineChart legendBottom(boolean value) {
        this.legendBottom = value;
        return this;
    }

    public LineChart zeroLine(boolean value) {
        this.zeroLine = value;
        return this;
    }

    public LineChart integerX(boolean value) {
        this.integerX = value;
        return this;
    }

    /** Фиксированный диапазон оси X (step = null — шаг делений подбирается автоматически). */
    public LineChart xRange(double min, double max, Double step) {
        this.xMinFixed = min;
        this.xMaxFixed = max;
        this.xStepFixed = step;
        return this;
    }

    public LineChart yRange(double min, double max, Double step) {
        this.yMinFixed = min;
        this.yMaxFixed = max;
        this.yStepFixed = step;
        return this;
    }

    public LineChart addSeries(String name, double[] x, double[] y, Color color,
                               Style style, boolean markers) {
        series.add(new Series(name, x, y, color, style, markers));
        return this;
    }

    /** Одна отмеченная точка (отображается в легенде). */
    public LineChart addPoint(String name, double x, double y, Color color) {
        return addSeries(name, new double[]{x}, new double[]{y}, color, Style.POINTS, true);
    }

    /** Вертикальная пунктирная линия x = const с подписью. */
    public LineChart addVLine(double x, String label, Color color) {
        vLines.add(new RefLine(x, label, color));
        return this;
    }

    /** Горизонтальная пунктирная линия y = const с подписью (например, уровень точности ε). */
    public LineChart addHLine(double y, String label, Color color) {
        hLines.add(new RefLine(y, label, color));
        return this;
    }

    /** Текстовая подпись у точки (x, y) со смещением (dx, dy) в пикселях. */
    public LineChart addText(double x, double y, String text, int dx, int dy) {
        notes.add(new Note(x, y, text, dx, dy));
        return this;
    }

    /** Размер области построения для заданного размера изображения (для одинакового масштаба осей). */
    public static int[] plotAreaSize(int width, int height) {
        return new int[]{width - LEFT - RIGHT, height - TOP - BOTTOM};
    }

    /** Высота изображения, при которой масштабы осей X и Y совпадают. */
    public static int heightForEqualAspect(int width, double xSpan, double ySpan) {
        int pw = width - LEFT - RIGHT;
        return (int) Math.round(pw * ySpan / xSpan) + TOP + BOTTOM;
    }

    // ---------------------------------------------------------------- render

    public void save(Path file, int width, int height) throws IOException {
        write(render(width, height), file);
    }

    public static void write(BufferedImage image, Path file) throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        ImageIO.write(image, "png", file.toFile());
    }

    /**
     * Склеивает несколько графиков в одно изображение по горизонтали
     * и подписывает их буквами «а)», «б)», ...
     */
    public static BufferedImage sideBySide(String[] captions, BufferedImage... parts) {
        int captionH = 60;
        int w = 0;
        int h = 0;
        for (BufferedImage p : parts) {
            w += p.getWidth();
            h = Math.max(h, p.getHeight());
        }
        BufferedImage image = new BufferedImage(w, h + captionH, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, image.getWidth(), image.getHeight());
        g.setFont(new Font("DejaVu Sans", Font.PLAIN, 30));
        FontMetrics fm = g.getFontMetrics();
        int x = 0;
        for (int i = 0; i < parts.length; i++) {
            g.drawImage(parts[i], x, 0, null);
            String c = captions[i];
            g.setColor(Color.BLACK);
            g.drawString(c, x + (parts[i].getWidth() - fm.stringWidth(c)) / 2f, h + 38);
            x += parts[i].getWidth();
        }
        g.dispose();
        return image;
    }

    public BufferedImage render(int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);

        int pw = width - LEFT - RIGHT;
        int ph = height - TOP - BOTTOM;

        // --- диапазоны данных
        double xMin = Double.POSITIVE_INFINITY, xMax = Double.NEGATIVE_INFINITY;
        double yMin = Double.POSITIVE_INFINITY, yMax = Double.NEGATIVE_INFINITY;
        for (Series s : series) {
            for (int i = 0; i < s.x().length; i++) {
                double yv = transformY(s.y()[i]);
                if (!Double.isFinite(yv) || !Double.isFinite(s.x()[i])) {
                    continue;
                }
                xMin = Math.min(xMin, s.x()[i]);
                xMax = Math.max(xMax, s.x()[i]);
                yMin = Math.min(yMin, yv);
                yMax = Math.max(yMax, yv);
            }
        }
        for (RefLine h : hLines) {
            double yv = transformY(h.value());
            yMin = Math.min(yMin, yv);
            yMax = Math.max(yMax, yv);
        }

        double[] xTicks;
        double[] yTicks;
        if (xMinFixed != null) {
            xMin = xMinFixed;
            xMax = xMaxFixed;
            double step = xStepFixed != null ? xStepFixed : niceStep((xMax - xMin) / 8.0);
            xTicks = ticks(Math.ceil(xMin / step - 1e-9) * step, xMax, step);
        } else if (integerX) {
            double step = Math.ceil(Math.max(1.0, niceStep((xMax - xMin) / 10.0)));
            xMin = xMin - 0.5;
            xMax = Math.ceil((xMax + 0.5) / step) * step;
            xTicks = ticks(Math.ceil(xMin / step) * step, xMax, step);
        } else {
            double step = niceStep((xMax - xMin) / 8.0);
            xMin = Math.floor(xMin / step) * step;
            xMax = Math.ceil(xMax / step) * step;
            xTicks = ticks(xMin, xMax, step);
        }
        if (yMinFixed != null) {
            yMin = transformY(yMinFixed);
            yMax = transformY(yMaxFixed);
            double step = yStepFixed != null ? yStepFixed : niceStep((yMax - yMin) / 8.0);
            yTicks = ticks(Math.ceil(yMin / step - 1e-9) * step, yMax, step);
        } else if (logY) {
            yMin = Math.floor(yMin);
            yMax = Math.ceil(yMax);
            if (yMax == yMin) {
                yMax = yMin + 1;
            }
            double step = Math.max(1.0, Math.ceil((yMax - yMin) / 10.0));
            yTicks = ticks(yMin, yMax, step);
        } else {
            double step = niceStep((yMax - yMin) / 8.0);
            yMin = Math.floor(yMin / step) * step;
            yMax = Math.ceil(yMax / step) * step;
            yTicks = ticks(yMin, yMax, step);
        }

        final double fxMin = xMin, fxMax = xMax, fyMin = yMin, fyMax = yMax;
        DoubleUnaryOperator px = v -> LEFT + (v - fxMin) / (fxMax - fxMin) * pw;
        DoubleUnaryOperator py = v -> TOP + ph - (v - fyMin) / (fyMax - fyMin) * ph;

        // --- сетка и подписи делений
        g.setFont(TICK_FONT);
        FontMetrics tfm = g.getFontMetrics();
        g.setStroke(new BasicStroke(1.2f));
        for (double t : xTicks) {
            double sx = px.applyAsDouble(t);
            g.setColor(new Color(225, 225, 225));
            g.draw(new Line2D.Double(sx, TOP, sx, TOP + ph));
            g.setColor(Color.DARK_GRAY);
            String s = formatTick(t, integerX);
            g.drawString(s, (float) (sx - tfm.stringWidth(s) / 2.0), TOP + ph + 32);
        }
        for (double t : yTicks) {
            double sy = py.applyAsDouble(t);
            g.setColor(new Color(225, 225, 225));
            g.draw(new Line2D.Double(LEFT, sy, LEFT + pw, sy));
            g.setColor(Color.DARK_GRAY);
            if (logY) {
                drawPowerOfTen(g, (int) Math.round(t), LEFT - 12, (float) (sy + 8));
            } else {
                String s = formatTick(t, false);
                g.drawString(s, (float) (LEFT - 12 - tfm.stringWidth(s)), (float) (sy + 8));
            }
        }

        if (zeroLine && !logY && fyMin < 0 && fyMax > 0) {
            g.setColor(Color.BLACK);
            g.setStroke(new BasicStroke(2f));
            double sy = py.applyAsDouble(0);
            g.draw(new Line2D.Double(LEFT, sy, LEFT + pw, sy));
        }

        // --- опорные линии
        Stroke refStroke = new BasicStroke(2.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f,
                new float[]{10f, 8f}, 0f);
        g.setFont(LABEL_FONT);
        FontMetrics lfm = g.getFontMetrics();
        for (RefLine v : vLines) {
            double sx = px.applyAsDouble(v.value());
            g.setColor(v.color());
            g.setStroke(refStroke);
            g.draw(new Line2D.Double(sx, TOP, sx, TOP + ph));
            g.drawString(v.label(), (float) (sx + 8), TOP + 34);
        }
        for (RefLine h : hLines) {
            double sy = py.applyAsDouble(transformY(h.value()));
            g.setColor(h.color());
            g.setStroke(refStroke);
            g.draw(new Line2D.Double(LEFT, sy, LEFT + pw, sy));
            g.drawString(h.label(), (float) (LEFT + pw - lfm.stringWidth(h.label()) - 12), (float) (sy - 10));
        }

        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(2f));
        g.draw(new Rectangle2D.Double(LEFT, TOP, pw, ph));

        // --- серии
        Shape oldClip = g.getClip();
        g.setClip(new Rectangle2D.Double(LEFT - 10, TOP - 10, pw + 20, ph + 20));
        for (Series s : series) {
            g.setColor(s.color());
            if (s.style() != Style.POINTS) {
                g.setStroke(strokeFor(s.style(), 3.5f));
                Path2D path = new Path2D.Double();
                boolean started = false;
                for (int i = 0; i < s.x().length; i++) {
                    double yv = transformY(s.y()[i]);
                    if (!Double.isFinite(yv)) {
                        started = false;
                        continue;
                    }
                    double sx = px.applyAsDouble(s.x()[i]);
                    double sy = py.applyAsDouble(yv);
                    if (!started) {
                        path.moveTo(sx, sy);
                        started = true;
                    } else {
                        path.lineTo(sx, sy);
                    }
                }
                Shape clip = g.getClip();
                g.setClip(new Rectangle2D.Double(LEFT, TOP, pw, ph));
                g.draw(path);
                g.setClip(clip);
            }
            if (s.markers()) {
                double r = s.style() == Style.POINTS ? 10 : 6;
                for (int i = 0; i < s.x().length; i++) {
                    double yv = transformY(s.y()[i]);
                    if (!Double.isFinite(yv)) {
                        continue;
                    }
                    double sx = px.applyAsDouble(s.x()[i]);
                    double sy = py.applyAsDouble(yv);
                    g.setColor(s.color());
                    g.fill(new Ellipse2D.Double(sx - r, sy - r, 2 * r, 2 * r));
                    if (s.style() == Style.POINTS) {
                        g.setColor(Color.BLACK);
                        g.setStroke(new BasicStroke(2f));
                        g.draw(new Ellipse2D.Double(sx - r, sy - r, 2 * r, 2 * r));
                    }
                }
            }
        }
        g.setClip(oldClip);

        g.setFont(LABEL_FONT);
        g.setColor(Color.BLACK);
        for (Note n : notes) {
            double sx = px.applyAsDouble(n.x());
            double sy = py.applyAsDouble(transformY(n.y()));
            g.drawString(n.text(), (float) (sx + n.dx()), (float) (sy + n.dy()));
        }

        // --- заголовок и подписи осей
        g.setColor(Color.BLACK);
        g.setFont(TITLE_FONT);
        FontMetrics fm = g.getFontMetrics();
        g.drawString(title, LEFT + (pw - fm.stringWidth(title)) / 2f, TOP - 28);
        g.setFont(LABEL_FONT);
        fm = g.getFontMetrics();
        g.drawString(xLabel, LEFT + (pw - fm.stringWidth(xLabel)) / 2f, height - 28);
        AffineTransform saved = g.getTransform();
        g.rotate(-Math.PI / 2);
        g.drawString(yLabel, -(TOP + (ph + fm.stringWidth(yLabel)) / 2f), 40);
        g.setTransform(saved);

        drawLegend(g, LEFT, LEFT + pw, TOP, TOP + ph);
        g.dispose();
        return image;
    }

    private static Stroke strokeFor(Style style, float width) {
        if (style == Style.DOTTED) {
            return new BasicStroke(width + 1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10f,
                    new float[]{1f, 11f}, 0f);
        }
        return style == Style.DASHED
                ? new BasicStroke(width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10f,
                new float[]{14f, 10f}, 0f)
                : new BasicStroke(width, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
    }

    private void drawLegend(Graphics2D g, int leftEdge, int rightEdge, int top, int bottom) {
        List<Series> named = series.stream()
                .filter(s -> s.name() != null && !s.name().isEmpty()).toList();
        if (named.isEmpty()) {
            return;
        }
        g.setFont(LABEL_FONT);
        FontMetrics fm = g.getFontMetrics();
        int maxW = named.stream().mapToInt(s -> fm.stringWidth(s.name())).max().orElse(0);
        int rowH = 40;
        int boxW = maxW + 100;
        int boxH = rowH * named.size() + 20;
        int x0 = legendLeft ? leftEdge + 20 : rightEdge - boxW - 20;
        int y0 = legendBottom ? bottom - boxH - 20 : top + 20;
        g.setColor(new Color(255, 255, 255, 235));
        g.fillRect(x0, y0, boxW, boxH);
        g.setColor(Color.GRAY);
        g.setStroke(new BasicStroke(1.5f));
        g.drawRect(x0, y0, boxW, boxH);
        for (int i = 0; i < named.size(); i++) {
            Series s = named.get(i);
            int cy = y0 + 10 + rowH * i + rowH / 2;
            g.setColor(s.color());
            if (s.style() != Style.POINTS) {
                g.setStroke(strokeFor(s.style(), 3.5f));
                g.drawLine(x0 + 15, cy, x0 + 70, cy);
            }
            if (s.markers()) {
                double r = s.style() == Style.POINTS ? 10 : 6;
                g.fill(new Ellipse2D.Double(x0 + 42.5 - r, cy - r, 2 * r, 2 * r));
                if (s.style() == Style.POINTS) {
                    g.setColor(Color.BLACK);
                    g.setStroke(new BasicStroke(2f));
                    g.draw(new Ellipse2D.Double(x0 + 42.5 - r, cy - r, 2 * r, 2 * r));
                }
            }
            g.setColor(Color.BLACK);
            g.drawString(s.name(), x0 + 82, cy + 9);
        }
    }

    private void drawPowerOfTen(Graphics2D g, int exp, int rightX, float baseline) {
        String base = "10";
        String e = Integer.toString(exp).replace('-', '\u2212');
        g.setFont(EXP_FONT);
        int ew = g.getFontMetrics().stringWidth(e);
        g.setFont(TICK_FONT);
        int bw = g.getFontMetrics().stringWidth(base);
        float x = rightX - ew - bw - 2;
        g.drawString(base, x, baseline);
        g.setFont(EXP_FONT);
        g.drawString(e, x + bw + 2, baseline - 11);
        g.setFont(TICK_FONT);
    }

    private double transformY(double y) {
        if (!logY) {
            return y;
        }
        return y > 0 ? Math.log10(y) : Double.NaN;
    }

    private static double niceStep(double raw) {
        if (raw <= 0 || !Double.isFinite(raw)) {
            return 1.0;
        }
        double p = Math.pow(10, Math.floor(Math.log10(raw)));
        double m = raw / p;
        double nice = m < 1.5 ? 1 : m < 3 ? 2 : m < 7 ? 5 : 10;
        return nice * p;
    }

    private static double[] ticks(double from, double to, double step) {
        List<Double> list = new ArrayList<>();
        for (int i = 0; ; i++) {
            double t = from + i * step;
            if (t > to + step * 1e-6) {
                break;
            }
            list.add(Math.abs(t) < step * 1e-9 ? 0.0 : t);
        }
        return list.stream().mapToDouble(Double::doubleValue).toArray();
    }

    /** Число с десятичной запятой и типографским минусом. */
    public static String ru(double v, int digits) {
        return String.format(Locale.US, "%." + digits + "f", v).replace('.', ',').replace('-', '\u2212');
    }

    private static String formatTick(double v, boolean integer) {
        if (integer || Math.abs(v - Math.rint(v)) < 1e-9) {
            return String.format(Locale.US, "%d", Math.round(v)).replace('-', '\u2212');
        }
        String s = String.format(Locale.US, "%.4f", v);
        s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
        return s.replace('.', ',').replace('-', '\u2212');
    }
}
