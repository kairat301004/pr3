package lab3.output;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Простая запись таблиц в CSV (разделитель — запятая, десятичная точка). */
public final class Csv {

    private final Path file;
    private final List<String> lines = new ArrayList<>();

    public Csv(Path file, String... header) {
        this.file = file;
        lines.add(String.join(",", header));
    }

    public Csv row(Object... values) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            Object v = values[i];
            if (v instanceof Double d) {
                sb.append(Double.isNaN(d) ? "" : String.format(Locale.US, "%.15e", d));
            } else {
                sb.append(v);
            }
        }
        lines.add(sb.toString());
        return this;
    }

    public void save() throws IOException {
        Files.createDirectories(file.toAbsolutePath().getParent());
        Files.write(file, lines, StandardCharsets.UTF_8);
    }
}
