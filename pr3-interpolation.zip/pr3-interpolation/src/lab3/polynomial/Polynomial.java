package lab3.polynomial;

import java.util.Arrays;
import java.util.Locale;

/**
 * Многочлен P(x) = a0 + a1 x + ... + am x^m в стандартном (мономиальном) виде.
 * Значение вычисляется по схеме Горнера.
 */
public final class Polynomial {

    private final double[] a;

    public Polynomial(double... coefficients) {
        if (coefficients.length == 0) {
            throw new IllegalArgumentException("Нужен хотя бы один коэффициент");
        }
        this.a = coefficients.clone();
    }

    public double value(double x) {
        double p = a[a.length - 1];
        for (int k = a.length - 2; k >= 0; k--) {
            p = p * x + a[k];
        }
        return p;
    }

    public int degree() {
        return a.length - 1;
    }

    /** Копия коэффициентов a0..am. */
    public double[] coefficients() {
        return a.clone();
    }

    /** Произведение на (x - c). */
    public Polynomial timesLinear(double c) {
        double[] r = new double[a.length + 1];
        for (int k = 0; k < a.length; k++) {
            r[k + 1] += a[k];
            r[k] -= c * a[k];
        }
        return new Polynomial(r);
    }

    /** Прибавление константы. */
    public Polynomial plus(double c) {
        double[] r = a.clone();
        r[0] += c;
        return new Polynomial(r);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int k = a.length - 1; k >= 0; k--) {
            sb.append(String.format(Locale.US, "%+.6e", a[k]));
            if (k > 0) {
                sb.append("*x^").append(k).append(' ');
            }
        }
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Polynomial p && Arrays.equals(a, p.a);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(a);
    }
}
