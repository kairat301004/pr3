package lab3.approximation;

import lab3.linear.GaussSolver;
import lab3.polynomial.Polynomial;

/**
 * Аппроксимация многочленом степени m методом наименьших квадратов.
 *
 * <p>Коэффициенты a_0..a_m минимизируют S = sum_i (P(x_i) - y_i)^2 и находятся из
 * нормальной системы sum_k a_k * sum_i x_i^(j+k) = sum_i y_i x_i^j, j = 0..m,
 * которая решается методом Гаусса.</p>
 */
public final class LeastSquares {

    /**
     * Результат аппроксимации.
     *
     * @param degree        степень многочлена m
     * @param polynomial    найденный многочлен
     * @param sumSquares    сумма квадратов отклонений S
     * @param sigma         среднеквадратичное отклонение sqrt(S / (n - m - 1)); NaN при n - m - 1 = 0
     * @param residuals     отклонения r_i = P(x_i) - y_i
     * @param orthogonality max_j |sum_i r_i x_i^j| — проверка условия минимума (должна быть ~0)
     */
    public record Fit(int degree, Polynomial polynomial, double sumSquares, double sigma,
                      double[] residuals, double orthogonality) {
    }

    private LeastSquares() {
    }

    public static Fit fit(double[] x, double[] y, int m) {
        int n = x.length;
        if (y.length != n) {
            throw new IllegalArgumentException("Массивы x и y должны быть одной длины");
        }
        if (m < 0 || m >= n) {
            throw new IllegalArgumentException("Степень должна быть в диапазоне 0..n-1");
        }

        // Суммы степеней sum x^p, p = 0..2m, и правые части sum y x^j.
        double[] powerSums = new double[2 * m + 1];
        double[] rhs = new double[m + 1];
        for (int i = 0; i < n; i++) {
            double p = 1.0;
            for (int k = 0; k <= 2 * m; k++) {
                powerSums[k] += p;
                if (k <= m) {
                    rhs[k] += y[i] * p;
                }
                p *= x[i];
            }
        }
        double[][] gram = new double[m + 1][m + 1];
        for (int j = 0; j <= m; j++) {
            for (int k = 0; k <= m; k++) {
                gram[j][k] = powerSums[j + k];
            }
        }
        Polynomial poly = new Polynomial(GaussSolver.solve(gram, rhs));

        double[] r = new double[n];
        double s = 0.0;
        for (int i = 0; i < n; i++) {
            r[i] = poly.value(x[i]) - y[i];
            s += r[i] * r[i];
        }
        double sigma = n - m - 1 > 0 ? Math.sqrt(s / (n - m - 1)) : Double.NaN;

        double orth = 0.0;
        for (int j = 0; j <= m; j++) {
            double sum = 0.0;
            for (int i = 0; i < n; i++) {
                sum += r[i] * Math.pow(x[i], j);
            }
            orth = Math.max(orth, Math.abs(sum));
        }
        return new Fit(m, poly, s, sigma, r, orth);
    }

    /**
     * Критические значения распределения Фишера F(0,95; 1, nu) = t(0,975; nu)^2, nu = 1..10.
     */
    private static final double[] F_CRIT_005 = {
            161.448, 18.513, 10.128, 7.709, 6.608, 5.987, 5.591, 5.318, 5.117, 4.965
    };

    /** Критическое значение F(0,95; 1, nu). */
    public static double fCritical(int nu) {
        if (nu < 1 || nu > F_CRIT_005.length) {
            throw new IllegalArgumentException("Табличное значение задано для nu = 1.." + F_CRIT_005.length);
        }
        return F_CRIT_005[nu - 1];
    }

    /**
     * Статистика Фишера для проверки значимости повышения степени m -> m + 1:
     * F = (S_m - S_(m+1)) / (S_(m+1) / (n - m - 2)).
     */
    public static double fStatistic(Fit lower, Fit higher, int n) {
        int nu = n - higher.degree() - 1;
        return (lower.sumSquares() - higher.sumSquares()) / (higher.sumSquares() / nu);
    }

    /**
     * Выбор степени по F-критерию (уровень значимости 0,05): степень повышается,
     * пока уменьшение суммы квадратов статистически значимо.
     */
    public static int degreeByFTest(double[] x, double[] y, int maxDegree) {
        int n = x.length;
        Fit current = fit(x, y, 0);
        for (int m = 1; m <= maxDegree; m++) {
            Fit next = fit(x, y, m);
            if (fStatistic(current, next, n) <= fCritical(n - m - 1)) {
                return m - 1;
            }
            current = next;
        }
        return maxDegree;
    }

    /**
     * Ошибка перекрёстной проверки с исключением по одному (leave-one-out):
     * многочлен степени m строится без i-го узла и сравнивается с y_i;
     * возвращается sqrt(mean((P^(-i)(x_i) - y_i)^2)).
     */
    public static double leaveOneOutError(double[] x, double[] y, int m) {
        int n = x.length;
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
            double[] xs = new double[n - 1];
            double[] ys = new double[n - 1];
            for (int j = 0, k = 0; j < n; j++) {
                if (j != i) {
                    xs[k] = x[j];
                    ys[k] = y[j];
                    k++;
                }
            }
            double e = fit(xs, ys, m).polynomial().value(x[i]) - y[i];
            sum += e * e;
        }
        return Math.sqrt(sum / n);
    }
}
