package lab3.interpolation;

import lab3.polynomial.Polynomial;

/**
 * Интерполяционный многочлен Ньютона с разделёнными разностями:
 * N(x) = f[x0] + f[x0,x1](x - x0) + ... + f[x0..xn](x - x0)...(x - x_(n-1)).
 */
public final class NewtonPolynomial {

    private final double[] x;
    /** dd[k][i] = f[x_i, ..., x_(i+k)] — разделённая разность порядка k. */
    private final double[][] dd;

    public NewtonPolynomial(double[] x, double[] y) {
        if (x.length != y.length || x.length == 0) {
            throw new IllegalArgumentException("Массивы узлов и значений должны быть одной длины");
        }
        int n = x.length;
        this.x = x.clone();
        this.dd = new double[n][];
        dd[0] = y.clone();
        for (int k = 1; k < n; k++) {
            dd[k] = new double[n - k];
            for (int i = 0; i < n - k; i++) {
                double denominator = x[i + k] - x[i];
                if (denominator == 0.0) {
                    throw new IllegalArgumentException("Узлы интерполяции должны быть различны");
                }
                dd[k][i] = (dd[k - 1][i + 1] - dd[k - 1][i]) / denominator;
            }
        }
    }

    /** Коэффициенты многочлена Ньютона: f[x0], f[x0,x1], ..., f[x0..xn]. */
    public double[] coefficients() {
        double[] c = new double[x.length];
        for (int k = 0; k < x.length; k++) {
            c[k] = dd[k][0];
        }
        return c;
    }

    /** Таблица разделённых разностей (копия). */
    public double[][] dividedDifferences() {
        double[][] copy = new double[dd.length][];
        for (int k = 0; k < dd.length; k++) {
            copy[k] = dd[k].clone();
        }
        return copy;
    }

    /** Значение N(t) по вложенной схеме (аналог схемы Горнера). */
    public double value(double t) {
        int n = x.length - 1;
        double p = dd[n][0];
        for (int k = n - 1; k >= 0; k--) {
            p = p * (t - x[k]) + dd[k][0];
        }
        return p;
    }

    /** Приведение многочлена Ньютона к стандартному виду a0 + a1 x + ... + an x^n. */
    public Polynomial toMonomial() {
        int n = x.length - 1;
        Polynomial p = new Polynomial(dd[n][0]);
        for (int k = n - 1; k >= 0; k--) {
            p = p.timesLinear(x[k]).plus(dd[k][0]);
        }
        return p;
    }

    public int degree() {
        return x.length - 1;
    }
}
