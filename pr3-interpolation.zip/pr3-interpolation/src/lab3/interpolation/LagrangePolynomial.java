package lab3.interpolation;

/**
 * Интерполяционный многочлен Лагранжа:
 * L(x) = sum_i y_i * l_i(x),  l_i(x) = prod_(j != i) (x - x_j) / (x_i - x_j).
 */
public final class LagrangePolynomial {

    private final double[] x;
    private final double[] y;

    public LagrangePolynomial(double[] x, double[] y) {
        if (x.length != y.length || x.length == 0) {
            throw new IllegalArgumentException("Массивы узлов и значений должны быть одной длины");
        }
        for (int i = 0; i < x.length; i++) {
            for (int j = i + 1; j < x.length; j++) {
                if (x[i] == x[j]) {
                    throw new IllegalArgumentException("Узлы интерполяции должны быть различны");
                }
            }
        }
        this.x = x.clone();
        this.y = y.clone();
    }

    /** Базисный многочлен l_i(t). */
    public double basis(int i, double t) {
        double p = 1.0;
        for (int j = 0; j < x.length; j++) {
            if (j != i) {
                p *= (t - x[j]) / (x[i] - x[j]);
            }
        }
        return p;
    }

    /** Значение L(t). */
    public double value(double t) {
        double sum = 0.0;
        for (int i = 0; i < x.length; i++) {
            sum += y[i] * basis(i, t);
        }
        return sum;
    }

    public int degree() {
        return x.length - 1;
    }
}
