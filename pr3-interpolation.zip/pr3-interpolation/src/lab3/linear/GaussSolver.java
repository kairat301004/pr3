package lab3.linear;

/**
 * Решение СЛАУ A x = b методом Гаусса с выбором главного элемента по столбцу.
 */
public final class GaussSolver {

    private static final double SINGULAR_EPS = 1e-14;

    private GaussSolver() {
    }

    public static double[] solve(double[][] matrix, double[] rhs) {
        int n = rhs.length;
        if (matrix.length != n) {
            throw new IllegalArgumentException("Размеры A и b не совпадают");
        }
        // Работаем с копиями, чтобы не портить входные данные.
        double[][] a = new double[n][];
        for (int i = 0; i < n; i++) {
            if (matrix[i].length != n) {
                throw new IllegalArgumentException("Матрица должна быть квадратной");
            }
            a[i] = matrix[i].clone();
        }
        double[] b = rhs.clone();

        // Прямой ход.
        for (int col = 0; col < n; col++) {
            int pivot = col;
            for (int row = col + 1; row < n; row++) {
                if (Math.abs(a[row][col]) > Math.abs(a[pivot][col])) {
                    pivot = row;
                }
            }
            if (Math.abs(a[pivot][col]) < SINGULAR_EPS) {
                throw new ArithmeticException("Матрица вырождена");
            }
            if (pivot != col) {
                double[] tmpRow = a[pivot];
                a[pivot] = a[col];
                a[col] = tmpRow;
                double tmp = b[pivot];
                b[pivot] = b[col];
                b[col] = tmp;
            }
            for (int row = col + 1; row < n; row++) {
                double factor = a[row][col] / a[col][col];
                for (int j = col; j < n; j++) {
                    a[row][j] -= factor * a[col][j];
                }
                b[row] -= factor * b[col];
            }
        }

        // Обратный ход.
        double[] x = new double[n];
        for (int row = n - 1; row >= 0; row--) {
            double sum = b[row];
            for (int j = row + 1; j < n; j++) {
                sum -= a[row][j] * x[j];
            }
            x[row] = sum / a[row][row];
        }
        return x;
    }
}
